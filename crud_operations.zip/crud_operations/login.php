<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login page</title>
    <link rel="stylesheet" href="login.css">
    
</head>
<body>
    <header>
    <h2>Login form</h2>
    
    <div class="container">
    <form action="" method="POST">
    
        <label>Email</label>
        <input type="email" name="email"><br><br>
<label>Password</label>
<input type="password" name="password"> <br><br>
<input type="submit" name="submit" value="Login">
    </form>
    </div>
    </header>
</body>
<?php
//chech if the form has been submitted

if(isset($_POST['submit'])){
    //Retrieve the user's input
    $email = $_POST['email'];
    $password = $_POST['password'];

    //validate the user's credentials
    if($email == 'admin@gmail.com' &&
    $password == '1234'){
        //start a new session
        session_start(); 

        //set sesseion variables
        $_SESSION['username']= $username;

        //Redirect the user to the homepage
        header('Location: index.php');
    }else{
        //display an error message
        echo"<p>Invalid username or email or password.</p>";
    }
}
?>
</html>